"""
Portfolio Manager — FastAPI backend skeleton.

Auth is functional (JWT, demo credentials). All portfolio/optimization/
rebalance/risk routes are stubs to be implemented.

Run:
    pip install fastapi "uvicorn[standard]" "python-jose[cryptography]" "passlib[bcrypt]"
    uvicorn main:app --reload
"""

from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import Depends, FastAPI, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from jose import JWTError, jwt
from passlib.context import CryptContext
from pydantic import BaseModel

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
SECRET_KEY = "CHANGE_ME_BEFORE_PRODUCTION"  # move to env var
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")

app = FastAPI(title="Portfolio Manager API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # restrict to frontend origin in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# Demo user store (replace with a real DB-backed user lookup)
# ---------------------------------------------------------------------------
DEMO_USER = {
    "email": "demo@portfolio.io",
    "hashed_password": pwd_context.hash("Demo@1234"),
    "full_name": "Demo Manager",
}


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------
class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"


class TokenData(BaseModel):
    email: Optional[str] = None


class User(BaseModel):
    email: str
    full_name: str


# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------
def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


def authenticate_user(email: str, password: str) -> Optional[dict]:
    if email != DEMO_USER["email"]:
        return None
    if not verify_password(password, DEMO_USER["hashed_password"]):
        return None
    return DEMO_USER


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + (
        expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


async def get_current_user(token: str = Depends(oauth2_scheme)) -> User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception

    if email != DEMO_USER["email"]:
        raise credentials_exception

    return User(email=DEMO_USER["email"], full_name=DEMO_USER["full_name"])


# ---------------------------------------------------------------------------
# Auth routes
# ---------------------------------------------------------------------------
@app.post("/auth/login", response_model=Token)
async def login(form_data: OAuth2PasswordRequestForm = Depends()):
    """
    Login with email (as 'username') + password.
    Demo credentials: demo@portfolio.io / Demo@1234
    """
    user = authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token = create_access_token(data={"sub": user["email"]})
    return Token(access_token=access_token)


@app.get("/auth/me", response_model=User)
async def read_current_user(current_user: User = Depends(get_current_user)):
    return current_user


# ---------------------------------------------------------------------------
# Dashboard (stub)
# ---------------------------------------------------------------------------
@app.get("/api/dashboard")
async def get_dashboard(current_user: User = Depends(get_current_user)):
    """Return total value, P&L, return, volatility, drawdown."""
    raise HTTPException(status_code=501, detail="Not implemented")


# ---------------------------------------------------------------------------
# Portfolio (stub)
# ---------------------------------------------------------------------------
@app.get("/api/portfolio/holdings")
async def get_holdings(current_user: User = Depends(get_current_user)):
    """Return holdings, allocation by asset class, cash, current vs target weights."""
    raise HTTPException(status_code=501, detail="Not implemented")


# ---------------------------------------------------------------------------
# Optimize (stub)
# ---------------------------------------------------------------------------
class OptimizeRequest(BaseModel):
    portfolio: str
    risk_profile: str
    method: str
    min_weight: float = 0
    max_weight: float = 100
    max_sector_exposure: float = 100
    target_volatility: Optional[float] = None
    long_only: bool = True
    cash_buffer: bool = False


@app.post("/api/optimize")
async def run_optimize(
    payload: OptimizeRequest, current_user: User = Depends(get_current_user)
):
    """Run portfolio optimization with the given method and constraints."""
    raise HTTPException(status_code=501, detail="Not implemented")


# ---------------------------------------------------------------------------
# Rebalance (stub)
# ---------------------------------------------------------------------------
@app.post("/api/rebalance")
async def generate_rebalance(current_user: User = Depends(get_current_user)):
    """Return current -> target weights, buy/sell recs, turnover/cost estimate."""
    raise HTTPException(status_code=501, detail="Not implemented")


# ---------------------------------------------------------------------------
# Risk analysis (stub)
# ---------------------------------------------------------------------------
@app.get("/api/risk")
async def get_risk_analysis(current_user: User = Depends(get_current_user)):
    """Return volatility, correlation matrix, VaR/CVaR."""
    raise HTTPException(status_code=501, detail="Not implemented")


@app.get("/")
async def root():
    return {"status": "ok", "service": "portfolio-manager-api"}
