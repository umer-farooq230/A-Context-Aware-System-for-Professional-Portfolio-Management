// ===== Auth guard =====
// Replace with a real check once /auth endpoints are live (verify JWT expiry, etc.)
if (!localStorage.getItem("access_token")) {
  window.location.href = "login.html";
}

// ===== Section navigation =====
const navItems = document.querySelectorAll(".nav-item");
const views = document.querySelectorAll(".view");
const pageTitle = document.getElementById("pageTitle");

const TITLES = {
  dashboard: "Dashboard",
  portfolio: "Portfolio",
  optimize: "Optimize",
  rebalance: "Rebalance",
  risk: "Risk Analysis",
};

navItems.forEach((btn) => {
  btn.addEventListener("click", () => {
    const target = btn.dataset.section;

    navItems.forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");

    views.forEach((v) => v.classList.remove("active"));
    document.getElementById(`view-${target}`).classList.add("active");

    pageTitle.textContent = TITLES[target];
  });
});

// ===== Logout =====
document.getElementById("logoutBtn").addEventListener("click", () => {
  localStorage.removeItem("access_token");
  window.location.href = "login.html";
});

// ===== Optimize action (stub) =====
document.getElementById("runOptimizeBtn")?.addEventListener("click", () => {
  // POST /optimize with { portfolio, riskProfile, method, constraints }
  // Populate #chart-frontier with the returned efficient frontier / target weights.
  console.log("Run optimization ->", {
    portfolio: document.getElementById("opt-portfolio").value,
    riskProfile: document.getElementById("opt-risk-profile").value,
    method: document.getElementById("opt-method").value,
    constraints: {
      minWeight: document.getElementById("c-min-weight").value,
      maxWeight: document.getElementById("c-max-weight").value,
      maxSector: document.getElementById("c-max-sector").value,
      targetVol: document.getElementById("c-target-vol").value,
      longOnly: document.getElementById("c-long-only").checked,
      cashBuffer: document.getElementById("c-cash-buffer").checked,
    },
  });
});

// ===== Rebalance action (stub) =====
document.getElementById("applyRebalanceBtn")?.addEventListener("click", () => {
  // POST /rebalance -> populate #rebalanceTable, turnover, txn-cost, trade-count
  console.log("Generate rebalance plan requested");
});

// ===== Data loading (stub) =====
// Once FastAPI backend is connected, fetch real data here, e.g.:
//
// async function loadDashboard() {
//   const res = await fetch("/api/dashboard", {
//     headers: { Authorization: `Bearer ${localStorage.getItem("access_token")}` }
//   });
//   const data = await res.json();
//   document.querySelector('[data-field="total-value"]').textContent = data.totalValue;
//   ...
// }
// loadDashboard();
